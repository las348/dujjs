// Assignment Code
var generateBtn = document.querySelector("#generate");
var passwordText = document.querySelector("#password");

// Write password to the #password input
function writePassword() {
  var password = generatePassword(finalPassword);
  var passwordText = document.querySelector("#password");
  passwordText.value = password;
}

//formulas to get characters
var special = function getSpecial() {
  symbols = "!#$%&'()*+,-./:;<=>?@[^_`{|}~";
  return symbols[Math.floor(Math.random() * symbols.length)];
}
var upper = function getUpper() {
  return String.fromCharCode(Math.floor(Math.random() * 26) + 65);
}
var lower = function getLower() {
  return String.fromCharCode(Math.floor(Math.random() * 26) + 97);
}
var number = function getNumber() {
  return String.fromCharCode(Math.floor(Math.random() * 48) + 10);
}
function pickPossible {
  var generatePassword = generatePassword();
  var 


}

//console.log(getNumber());
//console.log(getSpecial());
//console.log(getUpper());
//console.log(getLower());

var totPassword = [getSpecial(), getUpper(), getLower(),];
var finalPassword =
  totPassword[0] + totPassword[1] + totPassword[2] + totPassword[3];
console.log("it worked " + finalPassword);


var totPasswordIndex = 0;
var finalPassword = JSON.stringify(totPassword);

console.log(finalPassword);
//console.log(totPassword);

// Add event listener to generate button
document.querySelector("#userPassword").addEventListener("click", function generatePassword() {
  var userLength = parseInt(prompt("How long would you like the password to be?"));
  console.log(userLength);
  if ((userLength >= 8) && (userLength <= 128)) {
    var yesSpecial = confirm("Should I include special characters?");
    
  } else {
    alert("Start over");
  }
  if (yesSpecial == true) {
    var yesUpper = confirm("Should I include an upper case letter?");

  } else {
    alert("Start over");
  }
  if (yesUpper == true) {
    var yesLower = confirm("Should I include a lower case letter?");
    
  } else {
    alert("Start over");
  }
  if (yesLower == true) {
    var yesNumber = confirm("Should I include a number?");
    
  } else {
    alert("Start over");
  }
  if (yesNumber == true) {
    finalPassword
  }

  passwordText.value = password;

  /*else {
    alert("Start over");
  }*/
});